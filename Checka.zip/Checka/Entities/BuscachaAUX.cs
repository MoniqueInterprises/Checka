﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checka.Entities
{
    internal class BuscachaAUX
    {
        public string Carga = "";

        public BuscachaAUX() 
        {

        }
        public BuscachaAUX(string Carga)
        {
            this.Carga = Carga;
        }
    }
}
