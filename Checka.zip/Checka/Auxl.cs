﻿namespace Checka
{
    internal class Auxl
    {
        public static string Str = "server=localhost;uid=root;pwd=123456;database=checka";
        public static string BuscachaStr { get; private set; } = "server=mysql11-farm1.kinghost.net;uid=buscacha;pwd=dufemysql01;database=buscacha;";
    }
}
