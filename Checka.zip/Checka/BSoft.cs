﻿using K4os.Compression.LZ4.Streams.Frames;
using MySql.Data.MySqlClient;
using Mysqlx.Crud;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Checka
{
    public partial class BSoft : Form
    {
        List<string> CTEs = new List<string>();
        decimal soma1 = 0, soma2 = 0;
        List<int> IDs = new List<int>();
        DataGridView CRBsoftDatagridSave = new DataGridView();
        List<DataGridViewRow> ListaRows = new List<DataGridViewRow>();

        public BSoft()
        {
            InitializeComponent();
        }

        private void PortalDataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void BuscarDescontos()
        {
            ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;
            using (ExcelPackage pacote = new ExcelPackage(new FileInfo("C:\\Users\\moniq\\desktop\\Info.xlsx")))
            {
                ExcelWorksheet planilha = pacote.Workbook.Worksheets.FirstOrDefault(sheet => sheet.Name == "CTE");
                foreach (DataGridViewRow row in BSoftDataGrid.Rows)
                {
                    if (row.IsNewRow) continue;
                    for (int i = 1; i < planilha.Dimension.Rows; i++)
                    {
                        if (planilha.Cells[i, 6].Value?.ToString() == row.Cells[1].Value?.ToString())
                        {
                            if (planilha.Cells[i, 15].Value?.ToString() != "0")
                            {
                                CTEs.Add(planilha.Cells[i, 6].Value?.ToString());
                                Descontos.Text += $"{row.Cells[1].Value?.ToString()} - RS${planilha.Cells[i, 15].Value?.ToString()}" + Environment.NewLine;
                            }
                        }
                    }
                }
            }
        }

        public void PintarPorCTE()
        {
            foreach (DataGridViewRow rows in BSoftDataGrid.Rows)
            {
                foreach (string cte in CTEs)
                {
                    if (rows.Cells[1].Value?.ToString().GetHashCode() == cte.GetHashCode())
                    {
                        if ((bool)rows.Cells[1].Value?.ToString().Equals(cte))
                        {
                            rows.Cells[1].Style.BackColor = Color.LightYellow;
                        }
                    }
                }
            }
        }

        private void RefreshBsoft_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conexao = new MySqlConnection(Auxl.Str))
            {
                conexao.Open();

                var command = new MySqlCommand();
                if (sender.ToString() == "A")
                {
                    command = new MySqlCommand("SELECT * FROM checka.crbsoft LIMIT 30", conexao);
                }
                else
                {
                    command = new MySqlCommand("SELECT * FROM checka.crbsoft", conexao);
                }

                var dataAdapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                conexao.Close();

                // 1. Cria o BindingSource
                BindingSource bs = new BindingSource();
                bs.DataSource = dataTable;

                // 2. Configura o BSoftDataGrid
                BSoftDataGrid.AutoGenerateColumns = false;
                BSoftDataGrid.Columns.Clear();

                // 3. Cria as colunas com filtro
                foreach (DataColumn col in dataTable.Columns)
                {
                    var colFiltro = new DataGridViewAutoFilterTextBoxColumn
                    {
                        DataPropertyName = col.ColumnName,
                        HeaderText = col.ColumnName,
                        Name = col.ColumnName,
                        SortMode = DataGridViewColumnSortMode.Programmatic
                    };

                    BSoftDataGrid.Columns.Add(colFiltro);
                }

                // 4. Atribui a fonte de dados
                BSoftDataGrid.DataSource = bs;
            }
            BSoftDataGrid.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Descontos.Text = string.Empty;
            CopiarDataGrid(BSoftDataGrid, CRBsoftDatagridSave);
            BuscarDescontos();
        }

        private void RefreshAcerto_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conexao = new MySqlConnection(Auxl.Str))
            {
                conexao.Open();

                var command = new MySqlCommand();
                if (sender.ToString() == "A")
                {
                    command = new MySqlCommand("SELECT Posicao, NumeroDocumento AS Doc, Total, Pagador, Empresa, ID FROM checka.acertobsoft LIMIT 30", conexao);
                }
                else
                {
                    command = new MySqlCommand("SELECT Posicao, NumeroDocumento AS Doc, Total, Pagador, Empresa, ID FROM checka.acertobsoft", conexao);
                }
                var dataAdapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                AcertoDataGrid.DataSource = dataTable;

                conexao.Close();
            }
        }

        private void RefreshPortal_Click(object sender, EventArgs e)
        {
            using (MySqlConnection conexao = new MySqlConnection(Auxl.Str))
            {
                conexao.Open();

                var command = new MySqlCommand();
                if (sender.ToString() == "A")
                {
                    command = new MySqlCommand(@"
                        SELECT 
                            MAX(FRETE) AS FRETE,
                            Idbus,
                            MAX(ID) AS ID,
                            MAX(`DATAEMBARQUE`) AS `DATAEMBARQUE`,
                            MAX(TRANSPORTADORA) AS TRANSPORTADORA,
                            MAX(VENCIMENTO) AS VENCIMENTO,
                            MAX(FATURAMENTO) AS FATURAMENTO,
                            MAX(`CODREVENDA`) AS `CODREVENDA`,
                            MAX(CENTRAL) AS CENTRAL,
                            SUM(CAST(REPLACE(`VALORFRETE`, ',', '.') AS DECIMAL(10,2))) AS `TOTAL_VALOR_FRETE`,
                            MAX(`OBSERVACOES`) AS `OBSERVACOES`,
                            MAX(`ANOTACOES`) AS `ANOTACOES`
                        FROM (
                            SELECT * FROM checka.principal
                            WHERE TRANSPORTADORA IN (
                                'VIA APPIA',
                                'VIA APPIA 3',
                                'VARSOVIA MG',
                                'VARSOVIA RJ',
                                'PROPRIO CARRO',
                                'PROPRIO CARRETA',
                                'PROPRIO TRUCK'
                            )
    
                            UNION ALL

                            SELECT * FROM checka.arquivo
                            WHERE TRANSPORTADORA IN (
                                'VIA APPIA',
                                'VIA APPIA 3',
                                'VARSOVIA MG',
                                'VARSOVIA RJ',
                                'PROPRIO CARRO',
                                'PROPRIO CARRETA',
                                'PROPRIO TRUCK'
                            )
                        ) AS combinados
                        GROUP BY Idbus
                        LIMIT 30", conexao);

                }
                else
                {
                    command = new MySqlCommand(@"
                        SELECT 
                            MAX(FRETE) AS FRETE,
                            Idbus,
                            MAX(ID) AS ID,
                            MAX(`DATAEMBARQUE`) AS `DATAEMBARQUE`,
                            MAX(TRANSPORTADORA) AS TRANSPORTADORA,
                            MAX(VENCIMENTO) AS VENCIMENTO,
                            MAX(FATURAMENTO) AS FATURAMENTO,
                            MAX(`CODREVENDA`) AS `CODREVENDA`,
                            MAX(CENTRAL) AS CENTRAL,
                            SUM(CAST(REPLACE(`VALORFRETE`, ',', '.') AS DECIMAL(10,2))) AS `TOTAL_VALOR_FRETE`,
                            MAX(`OBSERVACOES`) AS `OBSERVACOES`,
                            MAX(`ANOTACOES`) AS `ANOTACOES`
                        FROM (
                            SELECT * FROM checka.principal
                            WHERE TRANSPORTADORA IN (
                                'VIA APPIA',
                                'VIA APPIA 3',
                                'VARSOVIA MG',
                                'VARSOVIA RJ',
                                'PROPRIO CARRO',
                                'PROPRIO CARRETA',
                                'PROPRIO TRUCK'
                            )
    
                            UNION ALL

                            SELECT * FROM checka.arquivo
                            WHERE TRANSPORTADORA IN (
                                'VIA APPIA',
                                'VIA APPIA 3',
                                'VARSOVIA MG',
                                'VARSOVIA RJ',
                                'PROPRIO CARRO',
                                'PROPRIO CARRETA',
                                'PROPRIO TRUCK'
                            )
                        ) AS combinados
                        GROUP BY Idbus", conexao);
                }

                var dataAdapter = new MySqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);
                PortalDataGrid.DataSource = dataTable;

                conexao.Close();
            }
        }

        private void BSoft_Load(object sender, EventArgs e)
        {
            CTEs.Clear();
            RefreshBsoft_Click("A", e);
            RefreshAcerto_Click("A", e);
            RefreshPortal_Click("A", e);
            BSoftDataGrid.ColumnHeaderMouseClick += BSoftDataGrid_ColumnHeaderMouseClick;

            BSoftDataGrid.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            AcertoDataGrid.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            AcertoDataGrid.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

            PortalDataGrid.Columns[1].Visible = checkBoxCarga.Checked;
            PortalDataGrid.Columns[2].Visible = checkBoxID.Checked;
            PortalDataGrid.Columns[3].Visible = checkBoxDtEmbarque.Checked;
            PortalDataGrid.Columns[0].Visible = checkBoxFrete.Checked;
            PortalDataGrid.Columns[4].Visible = checkBoxTransportadora.Checked;
            PortalDataGrid.Columns[5].Visible = checkBoxVencimento.Checked;
            PortalDataGrid.Columns[6].Visible = checkBoxFaturamento.Checked;
            PortalDataGrid.Columns[7].Visible = checkBoxCodRevenda.Checked;
            PortalDataGrid.Columns[8].Visible = checkBoxCentral.Checked;
            PortalDataGrid.Columns[9].Visible = checkBoxTotalFrete.Checked;
            PortalDataGrid.Columns[10].Visible = checkBoxObs.Checked;
            PortalDataGrid.Columns[11].Visible = checkBoxAno.Checked;


        }

        private void Pesquisar_Click(object sender, EventArgs e)
        {
            if (CheckCRBsoft.Checked)
            {
                using (MySqlConnection conexao = new MySqlConnection(Auxl.Str))
                {
                    conexao.Open();
                    string columnQuery = @"
                SELECT COLUMN_NAME 
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = 'checka' 
                AND TABLE_NAME = 'crbsoft' 
                ORDER BY ORDINAL_POSITION";

                    MySqlCommand cmd = new MySqlCommand(columnQuery, conexao);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    string columns = "";
                    while (reader.Read())
                    {
                        if (columns.Length > 0)
                        {
                            columns += "OR ";
                        }
                        columns += reader["COLUMN_NAME"].ToString() + $" LIKE '%{textBox1.Text}%' ";
                    }
                    reader.Close();

                    var dataAdapter = new MySqlDataAdapter($"SELECT * FROM checka.crbsoft WHERE {columns}", conexao);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    BSoftDataGrid.DataSource = dataTable;
                    conexao.Close();
                }
                Descontos.Text = string.Empty;
                BuscarDescontos();
            }
            if (CheckAcerto.Checked)
            {
                using (MySqlConnection conexao = new MySqlConnection(Auxl.Str))
                {
                    conexao.Open();
                    string columnQuery = @"
                SELECT COLUMN_NAME 
                FROM INFORMATION_SCHEMA.COLUMNS 
                WHERE TABLE_SCHEMA = 'checka' 
                AND TABLE_NAME = 'acertobsoft' 
                ORDER BY ORDINAL_POSITION";

                    MySqlCommand cmd = new MySqlCommand(columnQuery, conexao);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    string columns = "";
                    while (reader.Read())
                    {
                        if (columns.Length > 0)
                        {
                            columns += "OR ";
                        }
                        columns += reader["COLUMN_NAME"].ToString() + $" LIKE '%{textBox1.Text}%' ";
                    }
                    reader.Close();

                    var dataAdapter = new MySqlDataAdapter($"SELECT * FROM checka.acertobsoft WHERE {columns}", conexao);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    AcertoDataGrid.DataSource = dataTable;
                    conexao.Close();
                }
            }
            if (CheckPortal.Checked)
            {
                if (PortalDataGrid.DataSource == null)
                {
                    MessageBox.Show("Nenhum dado carregado.");
                    return;
                }

                DataTable originalData = (DataTable)PortalDataGrid.DataSource;

                // Filtra os dados manualmente com LINQ, convertendo tudo pra string
                var filteredRows = originalData.AsEnumerable()
                    .Where(row => row.ItemArray.Any(field =>
                        field != null && field.ToString().IndexOf(textBox1.Text, StringComparison.OrdinalIgnoreCase) >= 0))
                    .ToList();

                if (filteredRows.Count == 0)
                {
                    MessageBox.Show("Nenhum resultado encontrado.");
                    return;
                }

                // Agrupa por CARGA
                var grouped = filteredRows
                    .GroupBy(row => row["IdBus"])
                    .Select(g =>
                    {
                        var first = g.First();
                        var newRow = originalData.NewRow();

                        foreach (DataColumn col in originalData.Columns)
                        {
                            if (col.ColumnName == "TOTAL_VALOR_FRETE")
                            {
                                // Soma os fretes
                                newRow[col.ColumnName] = g.Sum(r => Convert.ToDecimal(r["TOTAL_VALOR_FRETE"]));
                            }
                            else
                            {
                                newRow[col.ColumnName] = first[col.ColumnName];
                            }
                        }

                        return newRow;
                    }).ToList();

                // Monta novo DataTable com os dados agrupados
                DataTable result = originalData.Clone();
                foreach (var row in grouped)
                {
                    DataRow newRow = result.NewRow();
                    foreach (DataColumn col in result.Columns)
                    {
                        newRow[col.ColumnName] = row[col.ColumnName];
                    }
                    result.Rows.Add(newRow);
                }

                PortalDataGrid.DataSource = result;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (panel1.Visible)
            {
                PortalDataGrid.Columns[1].Visible = checkBoxCarga.Checked;
                PortalDataGrid.Columns[2].Visible = checkBoxID.Checked;
                PortalDataGrid.Columns[3].Visible = checkBoxDtEmbarque.Checked;
                PortalDataGrid.Columns[0].Visible = checkBoxFrete.Checked;
                PortalDataGrid.Columns[4].Visible = checkBoxTransportadora.Checked;
                PortalDataGrid.Columns[5].Visible = checkBoxVencimento.Checked;
                PortalDataGrid.Columns[6].Visible = checkBoxFaturamento.Checked;
                PortalDataGrid.Columns[7].Visible = checkBoxCodRevenda.Checked;
                PortalDataGrid.Columns[8].Visible = checkBoxCentral.Checked;
                PortalDataGrid.Columns[9].Visible = checkBoxTotalFrete.Checked;
                PortalDataGrid.Columns[10].Visible = checkBoxObs.Checked;
                PortalDataGrid.Columns[11].Visible = checkBoxAno.Checked;
            }
            panel1.Visible = !panel1.Visible;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;

            using (ExcelPackage pacote = new ExcelPackage(new FileInfo("C:\\Users\\moniq\\desktop\\Info.xlsx")))
            {
                ExcelWorksheet planilha = pacote.Workbook.Worksheets.FirstOrDefault(sheet => sheet.Name == "BSOFT");

                using (MySqlConnection conexao = new MySqlConnection(Auxl.Str))
                {
                    conexao.Open();

                    for (int i = 2; i < planilha.Dimension.Rows + 1; i++)
                    {
                        UInt64 numeroDocumento = Convert.ToUInt64(planilha.Cells[i, 50].Value?.ToString());
                        string cliente = planilha.Cells[i, 54].Value?.ToString();
                        string centroDeReceita = planilha.Cells[i, 61].Value?.ToString();
                        DateTime dataEmissao = DateTime.Parse(planilha.Cells[i, 105].Value?.ToString());
                        DateTime dataBaixa = DateTime.Parse(planilha.Cells[i, 113].Value?.ToString());
                        string valor = planilha.Cells[i, 28].Value?.ToString();
                        string frete = planilha.Cells[i, 117].Value?.ToString();
                        int empresa = int.Parse(planilha.Cells[i, 5].Value?.ToString());

                        string conc = planilha.Cells[i, 118].Value?.ToString(); // <- CONC (coluna 118)

                        // Verifica se o CONC já existe
                        string checkQuery = "SELECT Validado FROM checka.crbsoft WHERE CONC = @conc";
                        using (MySqlCommand checkCmd = new MySqlCommand(checkQuery, conexao))
                        {
                            checkCmd.Parameters.AddWithValue("@conc", conc);
                            object resultado = checkCmd.ExecuteScalar();

                            if (resultado == null)
                            {
                                // INSERT: não existe no banco
                                string insertQuery = @"
                            INSERT INTO checka.crbsoft 
                            (CONC, NumeroDocumento, Cliente, CentroDeReceita, Valor, DataEmissao, DataBaixa, Frete, Empresa)
                            VALUES 
                            (@conc, @numero, @cliente, @centro, @valor, @emissao, @baixa, @frete, @empresa)";
                                using (MySqlCommand insertCmd = new MySqlCommand(insertQuery, conexao))
                                {
                                    insertCmd.Parameters.AddWithValue("@conc", conc);
                                    insertCmd.Parameters.AddWithValue("@numero", numeroDocumento);
                                    insertCmd.Parameters.AddWithValue("@cliente", cliente);
                                    insertCmd.Parameters.AddWithValue("@centro", centroDeReceita);
                                    insertCmd.Parameters.AddWithValue("@valor", valor);
                                    insertCmd.Parameters.AddWithValue("@emissao", dataEmissao);
                                    insertCmd.Parameters.AddWithValue("@baixa", dataBaixa);
                                    insertCmd.Parameters.AddWithValue("@frete", frete);
                                    insertCmd.Parameters.AddWithValue("@empresa", empresa);
                                    insertCmd.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                string validado = resultado.ToString();
                                if (validado != "OK")
                                {
                                    // UPDATE: existe, mas não está validado
                                    string updateQuery = @"
                                UPDATE checka.crbsoft SET
                                    NumeroDocumento = @numero,
                                    Cliente = @cliente,
                                    CentroDeReceita = @centro,
                                    Valor = @valor,
                                    DataEmissao = @emissao,
                                    DataBaixa = @baixa,
                                    Frete = @frete,
                                    Empresa = @empresa
                                WHERE CONC = @conc";
                                    using (MySqlCommand updateCmd = new MySqlCommand(updateQuery, conexao))
                                    {
                                        updateCmd.Parameters.AddWithValue("@conc", conc);
                                        updateCmd.Parameters.AddWithValue("@numero", numeroDocumento);
                                        updateCmd.Parameters.AddWithValue("@cliente", cliente);
                                        updateCmd.Parameters.AddWithValue("@centro", centroDeReceita);
                                        updateCmd.Parameters.AddWithValue("@valor", valor);
                                        updateCmd.Parameters.AddWithValue("@emissao", dataEmissao);
                                        updateCmd.Parameters.AddWithValue("@baixa", dataBaixa);
                                        updateCmd.Parameters.AddWithValue("@frete", frete);
                                        updateCmd.Parameters.AddWithValue("@empresa", empresa);
                                        updateCmd.ExecuteNonQuery();
                                    }
                                }
                                // else: está validado como "OK", ignora
                            }
                        }
                    }

                    conexao.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;
            using (ExcelPackage pacote = new ExcelPackage(new FileInfo("C:\\Users\\moniq\\desktop\\Info.xlsx")))
            {
                ExcelWorksheet planilha = pacote.Workbook.Worksheets.FirstOrDefault(sheet => sheet.Name == "ACERTO BSOFT");
                using (MySqlConnection conexao = new MySqlConnection(Auxl.Str))
                {
                    conexao.Open();

                    for (int i = 2; i < planilha.Dimension.Rows + 1; i++)
                    {
                        UInt64 numerotitulo = Convert.ToUInt64(planilha.Cells[i, 5].Value?.ToString());
                        string posicao = planilha.Cells[i, 4].Value?.ToString();
                        string obs = planilha.Cells[i, 42].Value?.ToString();
                        string total = planilha.Cells[i, 37].Value?.ToString();
                        string pagador = planilha.Cells[i, 19].Value?.ToString();
                        int empresa = int.Parse(planilha.Cells[i, 2].Value?.ToString());

                        MySqlCommand comando = new MySqlCommand($"INSERT INTO checka.acertobsoft (Posicao, NumeroDocumento, Observacao, Total, Pagador, Empresa) VALUES (@Posicao, @NumeroDocumento, @Observacao, @Total, @Pagador, @Empresa);", conexao);
                        comando.Parameters.AddWithValue("@Posicao", posicao);
                        comando.Parameters.AddWithValue("@NumeroDocumento", numerotitulo);
                        comando.Parameters.AddWithValue("@Observacao", obs);
                        comando.Parameters.AddWithValue("@Total", total);
                        comando.Parameters.AddWithValue("@Pagador", pagador);
                        comando.Parameters.AddWithValue("@Empresa", empresa);

                        comando.ExecuteNonQuery();
                    }

                    conexao.Close();
                }
            }
        }

        private void BSoftDataGrid_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var grid = sender as DataGridView;
            var colIndex = e.ColumnIndex;

            if (grid.DataSource is BindingSource bs && bs.DataSource is DataTable dt)
            {
                string coluna = grid.Columns[colIndex].DataPropertyName;

                var valores = dt.AsEnumerable()
                                .Select(r => r[coluna]?.ToString())
                                .Distinct()
                                .OrderBy(v => v)
                                .ToList();

                int limiteInicial = 10;
                ContextMenuStrip menu = new ContextMenuStrip();
                menu.Items.Add("Todos", null, (s, a) => bs.RemoveFilter());

                // Mostrar os primeiros 10
                foreach (var val in valores.Take(limiteInicial))
                {
                    if (!string.IsNullOrWhiteSpace(val))
                    {
                        var item = new ToolStripMenuItem(val);
                        item.Click += (s, a) =>
                        {
                            bs.Filter = $"[{coluna}] = '{val.Replace("'", "''")}'";
                        };
                        menu.Items.Add(item);
                    }
                }

                // Se tiver mais de 10, adiciona a opção "Mostrar mais..."
                if (valores.Count > limiteInicial)
                {
                    menu.Items.Add("Mostrar mais...", null, (s, a) =>
                    {
                        ContextMenuStrip menuCompleto = new ContextMenuStrip();
                        menuCompleto.Items.Add("Todos", null, (s2, a2) => bs.RemoveFilter());

                        foreach (var val in valores)
                        {
                            if (!string.IsNullOrWhiteSpace(val))
                            {
                                var item = new ToolStripMenuItem(val);
                                item.Click += (s3, a3) =>
                                {
                                    bs.Filter = $"[{coluna}] = '{val.Replace("'", "''")}'";
                                };
                                menuCompleto.Items.Add(item);
                            }
                        }

                        // Posição onde o primeiro menu foi aberto
                        var headerRect = grid.GetCellDisplayRectangle(colIndex, -1, true);
                        var ptCompleto = new System.Drawing.Point(headerRect.Left + 100, headerRect.Bottom); // desloca um pouco pro lado
                        menuCompleto.Show(grid, ptCompleto);
                    });
                }

                var headerRectInicial = grid.GetCellDisplayRectangle(colIndex, -1, true);
                var ptInicial = new System.Drawing.Point(headerRectInicial.Left, headerRectInicial.Bottom);
                menu.Show(grid, ptInicial);
            }
            double soma = 0.0;
            try
            {
                foreach (DataGridViewRow row in BSoftDataGrid.Rows)
                {
                    soma += Convert.ToDouble(row.Cells[4].Value?.ToString(), System.Globalization.CultureInfo.InvariantCulture);
                }
            }
            catch (Exception ex)
            {
                return;
            }
            ValorSomadoCRBsoft.Text = "TOTAL: " + soma;
        }

        private void BSoftDataGrid_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            var culturaBR = new System.Globalization.CultureInfo("pt-BR");
            decimal soma = 0.0m;

            foreach (DataGridViewRow row in BSoftDataGrid.Rows)
            {
                if (row.IsNewRow) continue;
                if (row.Cells[4].Value != null &&
                    decimal.TryParse(row.Cells[4].Value.ToString(), NumberStyles.Any, culturaBR, out decimal valor))
                {
                    soma += valor;
                }
            }

            ValorSomadoCRBsoft.Text = "TOTAL: " + soma.ToString("N2", culturaBR);
            soma2 = soma;
            ValorDiff.Text = "DIFERENÇA: " + (soma1 - soma2).ToString("N2", culturaBR);
        }

        private void PortalDataGrid_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            var culturaBR = new System.Globalization.CultureInfo("pt-BR");
            decimal soma = 0.0m;

            foreach (DataGridViewRow row in PortalDataGrid.Rows)
            {
                if (row.IsNewRow) continue;
                if (row.Cells[4].Value != null &&
                    decimal.TryParse(row.Cells["TOTAL_VALOR_FRETE"].Value.ToString(), NumberStyles.Any, culturaBR, out decimal valor))
                {
                    soma += valor;
                }
            }

            ValorSomadoPortal.Text = "TOTAL: " + soma.ToString("N2", culturaBR);
            soma1 = soma;
            ValorDiff.Text = "DIFERENÇA: " + (soma1 - soma2).ToString("N2", culturaBR);
        }

        private void AcertoDataGrid_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            CultureInfo culturaBR = new CultureInfo("pt-BR");
            decimal soma = 0.0m;

            foreach (DataGridViewRow row in AcertoDataGrid.Rows)
            {
                if (row.Visible && row.Cells["Total"].Value != null) // <- ajuste o índice da coluna "Total" se necessário
                {
                    string valorStr = row.Cells["Total"].Value.ToString(); // índice da coluna "Total"
                    if (decimal.TryParse(valorStr, NumberStyles.Any, culturaBR, out decimal valor))
                    {
                        soma += valor;
                    }
                }
            }

            ValorSomadoAcerto.Text = "TOTAL: " + soma.ToString("N2", culturaBR);
        }

        private void FreteBotao_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show($"Deseja enviar as informações?", "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                using (MySqlConnection conexao = new MySqlConnection(Auxl.Str))
                {
                    conexao.Open();
                    new MySqlCommand(@"
                    INSERT INTO arquivo_bsoft (
                        ID,
                        NumeroDocumento,
                        Cliente,
                        CentroDeReceita,
                        Valor,
                        DataEmissao,
                        DataBaixa,
                        Frete,
                        Empresa,
                        Validado
                    )
                    SELECT
                        ID,
                        NumeroDocumento,
                        Cliente,
                        CentroDeReceita,
                        Valor,
                        DataEmissao,
                        DataBaixa,
                        Frete,
                        Empresa,
                        Validado
                    FROM checka.crbsoft AS src
                    WHERE Validado = 'OK'
                    AND NOT EXISTS (
                        SELECT 1 FROM arquivo_bsoft AS dest
                        WHERE
                            dest.ID = src.ID AND
                            dest.NumeroDocumento = src.NumeroDocumento AND
                            dest.Cliente = src.Cliente AND
                            dest.CentroDeReceita = src.CentroDeReceita AND
                            dest.Valor = src.Valor AND
                            dest.DataEmissao = src.DataEmissao AND
                            (dest.DataBaixa <=> src.DataBaixa) AND -- usando <=> para lidar com NULLs
                            dest.Frete = src.Frete AND
                            dest.Empresa = src.Empresa AND
                            dest.Validado = src.Validado
                    );", conexao).ExecuteNonQuery();

                    new MySqlCommand($"UPDATE checka.principal SET Validado = 'OK' WHERE Frete IN (SELECT Frete FROM checka.crbsoft WHERE Validado = 'OK');", conexao).ExecuteNonQuery();
                    conexao.Close();
                }
            }
            else
            {
                return;
            }
        }

        private void BSoftDataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            var row = BSoftDataGrid.Rows[e.RowIndex];
            if (row.IsNewRow) return;

            // Toggle "Validado"
            if (BSoftDataGrid.Columns[e.ColumnIndex].Name == "Validado")
            {
                var valorAtual = row.Cells["Validado"].Value?.ToString()?.Trim();
                if (string.IsNullOrEmpty(valorAtual))
                {
                    row.Cells["Validado"].Value = "OK";
                }
                else
                {
                    row.Cells["Validado"].Value = "OK";
                }

                // Garante que o valor é salvo no DataGridView
                BSoftDataGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);
                BSoftDataGrid.EndEdit();
            }

            // Adiciona o ID sempre que clicar em qualquer célula (sem duplicatas)
            int id = Convert.ToInt32(row.Cells[0].Value);
            if (!IDs.Contains(id))
                IDs.Add(id);
        }

        private void BSoftDataGrid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            var row = BSoftDataGrid.Rows[e.RowIndex];
            if (row.IsNewRow) return;
            if (BSoftDataGrid.Columns[e.ColumnIndex].Name == "Validado")
            {
                row.Cells["Validado"].Value = "";
            }
        }

        private void SalvarBsoft_Click(object sender, EventArgs e)
        {
            // Finaliza qualquer edição pendente
            BSoftDataGrid.EndEdit();
            BSoftDataGrid.CommitEdit(DataGridViewDataErrorContexts.Commit);

            // Atualiza a cópia da grid ANTES de continuar
            ListaRows.Clear();
            foreach (DataGridViewRow row in BSoftDataGrid.Rows)
            {
                if (!row.IsNewRow && row.Cells[0].Value != null)
                {
                    ListaRows.Add(row);
                }
            }

            // Aqui você salva os dados, mas usa ListaRows — que está atualizada
            using (MySqlConnection conexao = new MySqlConnection(Auxl.Str))
            {
                conexao.Open();
                foreach (DataGridViewRow row in ListaRows)
                {
                    int idAtual = Convert.ToInt32(row.Cells[0].Value);

                    if (IDs.Contains(idAtual))
                    {
                        string query = @"
                    UPDATE checka.crbsoft SET
                        NumeroDocumento = @NumeroDocumento,
                        Cliente = @Cliente,
                        CentroDeReceita = @CentroDeReceita,
                        Valor = @Valor,
                        DataEmissao = @DataEmissao,
                        DataBaixa = @DataBaixa,
                        Frete = @Frete,
                        Empresa = @Empresa,
                        Validado = @Validado
                    WHERE ID = @ID";

                        using (var command = new MySqlCommand(query, conexao))
                        {
                            command.Parameters.AddWithValue("@ID", row.Cells["ID"].Value ?? DBNull.Value);
                            command.Parameters.AddWithValue("@NumeroDocumento", row.Cells["NumeroDocumento"].Value ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Cliente", row.Cells["Cliente"].Value ?? DBNull.Value);
                            command.Parameters.AddWithValue("@CentroDeReceita", row.Cells["CentroDeReceita"].Value ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Valor", row.Cells["Valor"].Value ?? DBNull.Value);
                            command.Parameters.AddWithValue("@DataEmissao", row.Cells["DataEmissao"].Value ?? DBNull.Value);
                            command.Parameters.AddWithValue("@DataBaixa", row.Cells["DataBaixa"].Value ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Frete", row.Cells["Frete"].Value ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Empresa", row.Cells["Empresa"].Value ?? DBNull.Value);
                            command.Parameters.AddWithValue("@Validado", row.Cells["Validado"].Value ?? DBNull.Value);

                            command.ExecuteNonQuery();
                        }
                    }
                }
                conexao.Close();
            }

            MessageBox.Show("Alterações salvas!");
        }


        private void FreteBotao2_Click(object sender, EventArgs e)
        {
            new ArquivoBsoft().Show();
        }

        private void CrJoao_Click(object sender, EventArgs e)
        {
            new CheckJoao().Show();
        }

        private void CopiarDataGrid(DataGridView origem, DataGridView destino)
        {
            destino.Columns.Clear();
            destino.Rows.Clear();
            destino.AutoGenerateColumns = false;

            // Copiar colunas
            foreach (DataGridViewColumn coluna in origem.Columns)
            {
                destino.Columns.Add((DataGridViewColumn)coluna.Clone());
            }

            // Copiar valores das linhas
            foreach (DataGridViewRow row in origem.Rows)
            {
                if (!row.IsNewRow)
                {
                    int index = destino.Rows.Add();
                    for (int i = 0; i < row.Cells.Count; i++)
                    {
                        destino.Rows[index].Cells[i].Value = row.Cells[i].Value;
                    }
                }
            }
        }


    }
}
