﻿namespace Checka
{
    partial class Frete
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frete));
            Tabela = new DataGridView();
            Buscacha = new TextBox();
            label1 = new Label();
            label2 = new Label();
            Buscar = new Button();
            FreteText = new TextBox();
            RazaoSocialText = new TextBox();
            ValorText = new TextBox();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            ValorSomado = new TextBox();
            CodigoProdutoKardex = new TextBox();
            label8 = new Label();
            ValoresText = new TextBox();
            CTE = new Label();
            CTEText = new TextBox();
            label3 = new Label();
            ValoresDoc = new TextBox();
            label10 = new Label();
            PagadorPortal = new TextBox();
            button1 = new Button();
            button2 = new Button();
            label11 = new Label();
            button3 = new Button();
            SomaValorDoc = new TextBox();
            ValorTotalPortal = new TextBox();
            label12 = new Label();
            ValorDocPortal = new TextBox();
            label13 = new Label();
            CtePortal = new TextBox();
            button5 = new Button();
            VencimentoPortal = new TextBox();
            label14 = new Label();
            label15 = new Label();
            VencimentoPagar = new TextBox();
            label16 = new Label();
            RazaoSocialPagarText = new TextBox();
            DiferencaPortal = new Label();
            DiferencaPagar = new Label();
            DiferencaKardex = new Label();
            QuemFez = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            label9 = new Label();
            RevendasText = new TextBox();
            button4 = new Button();
            label17 = new Label();
            label18 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            label19 = new Label();
            label20 = new Label();
            label21 = new Label();
            ConfTextBox = new TextBox();
            label22 = new Label();
            ((System.ComponentModel.ISupportInitialize)Tabela).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // Tabela
            // 
            Tabela.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Tabela.Location = new Point(22, 131);
            Tabela.Name = "Tabela";
            Tabela.Size = new Size(692, 347);
            Tabela.TabIndex = 0;
            // 
            // Buscacha
            // 
            Buscacha.Location = new Point(2083, 131);
            Buscacha.Multiline = true;
            Buscacha.Name = "Buscacha";
            Buscacha.Size = new Size(100, 347);
            Buscacha.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 116);
            label1.Name = "label1";
            label1.Size = new Size(33, 15);
            label1.TabIndex = 3;
            label1.Text = "Frete";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(2114, 113);
            label2.Name = "label2";
            label2.Size = new Size(38, 15);
            label2.TabIndex = 4;
            label2.Text = "Carga";
            // 
            // Buscar
            // 
            Buscar.Location = new Point(1871, 11);
            Buscar.Name = "Buscar";
            Buscar.Size = new Size(94, 23);
            Buscar.TabIndex = 7;
            Buscar.Text = "Buscar";
            Buscar.UseVisualStyleBackColor = true;
            Buscar.Click += Buscar_Click;
            // 
            // FreteText
            // 
            FreteText.Location = new Point(1977, 12);
            FreteText.Name = "FreteText";
            FreteText.Size = new Size(100, 23);
            FreteText.TabIndex = 8;
            // 
            // RazaoSocialText
            // 
            RazaoSocialText.Location = new Point(1922, 131);
            RazaoSocialText.Multiline = true;
            RazaoSocialText.Name = "RazaoSocialText";
            RazaoSocialText.Size = new Size(155, 347);
            RazaoSocialText.TabIndex = 9;
            // 
            // ValorText
            // 
            ValorText.Location = new Point(1795, 484);
            ValorText.Name = "ValorText";
            ValorText.Size = new Size(121, 23);
            ValorText.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(1962, 113);
            label4.Name = "label4";
            label4.Size = new Size(75, 15);
            label4.TabIndex = 11;
            label4.Text = "Razao Social:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(1837, 113);
            label5.Name = "label5";
            label5.Size = new Size(36, 15);
            label5.TabIndex = 12;
            label5.Text = "Valor:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(461, 488);
            label6.Name = "label6";
            label6.Size = new Size(82, 15);
            label6.TabIndex = 14;
            label6.Text = "Valor somado:";
            // 
            // ValorSomado
            // 
            ValorSomado.Location = new Point(549, 484);
            ValorSomado.Name = "ValorSomado";
            ValorSomado.Size = new Size(133, 23);
            ValorSomado.TabIndex = 13;
            // 
            // CodigoProdutoKardex
            // 
            CodigoProdutoKardex.Location = new Point(1692, 131);
            CodigoProdutoKardex.Multiline = true;
            CodigoProdutoKardex.Name = "CodigoProdutoKardex";
            CodigoProdutoKardex.Size = new Size(100, 347);
            CodigoProdutoKardex.TabIndex = 17;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(1688, 113);
            label8.Name = "label8";
            label8.Size = new Size(109, 15);
            label8.TabIndex = 18;
            label8.Text = "Código do produto";
            // 
            // ValoresText
            // 
            ValoresText.Location = new Point(1795, 131);
            ValoresText.Multiline = true;
            ValoresText.Name = "ValoresText";
            ValoresText.Size = new Size(121, 347);
            ValoresText.TabIndex = 19;
            // 
            // CTE
            // 
            CTE.AutoSize = true;
            CTE.Location = new Point(1242, 113);
            CTE.Name = "CTE";
            CTE.Size = new Size(52, 15);
            CTE.TabIndex = 21;
            CTE.Text = "NF/DOC";
            // 
            // CTEText
            // 
            CTEText.Location = new Point(1211, 131);
            CTEText.Multiline = true;
            CTEText.Name = "CTEText";
            CTEText.Size = new Size(100, 347);
            CTEText.TabIndex = 20;
            CTEText.TextChanged += CTEText_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(1340, 113);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 23;
            label3.Text = "ValorDoc";
            // 
            // ValoresDoc
            // 
            ValoresDoc.Location = new Point(1317, 131);
            ValoresDoc.Multiline = true;
            ValoresDoc.Name = "ValoresDoc";
            ValoresDoc.Size = new Size(101, 347);
            ValoresDoc.TabIndex = 22;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(1951, 113);
            label10.Name = "label10";
            label10.Size = new Size(0, 15);
            label10.TabIndex = 26;
            label10.Click += label10_Click;
            // 
            // PagadorPortal
            // 
            PagadorPortal.Location = new Point(933, 131);
            PagadorPortal.Multiline = true;
            PagadorPortal.Name = "PagadorPortal";
            PagadorPortal.Size = new Size(165, 347);
            PagadorPortal.TabIndex = 25;
            // 
            // button1
            // 
            button1.Location = new Point(1211, 51);
            button1.Name = "button1";
            button1.Size = new Size(866, 23);
            button1.TabIndex = 29;
            button1.Text = "Control";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(22, 51);
            button2.Name = "button2";
            button2.Size = new Size(1184, 23);
            button2.TabIndex = 30;
            button2.Text = "Portal";
            button2.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(990, 113);
            label11.Name = "label11";
            label11.Size = new Size(51, 15);
            label11.TabIndex = 31;
            label11.Text = "Pagador";
            label11.Click += label11_Click;
            // 
            // button3
            // 
            button3.Location = new Point(1211, 80);
            button3.Name = "button3";
            button3.Size = new Size(475, 23);
            button3.TabIndex = 32;
            button3.Text = "Contas a Pagar";
            button3.UseVisualStyleBackColor = true;
            // 
            // SomaValorDoc
            // 
            SomaValorDoc.Location = new Point(1317, 484);
            SomaValorDoc.Name = "SomaValorDoc";
            SomaValorDoc.Size = new Size(101, 23);
            SomaValorDoc.TabIndex = 33;
            // 
            // ValorTotalPortal
            // 
            ValorTotalPortal.Location = new Point(826, 484);
            ValorTotalPortal.Name = "ValorTotalPortal";
            ValorTotalPortal.Size = new Size(101, 23);
            ValorTotalPortal.TabIndex = 38;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(847, 113);
            label12.Name = "label12";
            label12.Size = new Size(54, 15);
            label12.TabIndex = 37;
            label12.Text = "ValorDoc";
            // 
            // ValorDocPortal
            // 
            ValorDocPortal.Location = new Point(826, 131);
            ValorDocPortal.Multiline = true;
            ValorDocPortal.Name = "ValorDocPortal";
            ValorDocPortal.Size = new Size(101, 347);
            ValorDocPortal.TabIndex = 36;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(737, 113);
            label13.Name = "label13";
            label13.Size = new Size(59, 15);
            label13.TabIndex = 35;
            label13.Text = "Cte Portal";
            label13.Click += label13_Click;
            // 
            // CtePortal
            // 
            CtePortal.Location = new Point(720, 131);
            CtePortal.Multiline = true;
            CtePortal.Name = "CtePortal";
            CtePortal.Size = new Size(100, 347);
            CtePortal.TabIndex = 34;
            // 
            // button5
            // 
            button5.Location = new Point(1692, 80);
            button5.Name = "button5";
            button5.Size = new Size(385, 23);
            button5.TabIndex = 40;
            button5.Text = "Kardex";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // VencimentoPortal
            // 
            VencimentoPortal.Location = new Point(1104, 131);
            VencimentoPortal.Multiline = true;
            VencimentoPortal.Name = "VencimentoPortal";
            VencimentoPortal.Size = new Size(100, 347);
            VencimentoPortal.TabIndex = 41;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(1122, 113);
            label14.Name = "label14";
            label14.Size = new Size(70, 15);
            label14.TabIndex = 42;
            label14.Text = "Vencimento";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(1604, 113);
            label15.Name = "label15";
            label15.Size = new Size(70, 15);
            label15.TabIndex = 44;
            label15.Text = "Vencimento";
            // 
            // VencimentoPagar
            // 
            VencimentoPagar.Location = new Point(1585, 131);
            VencimentoPagar.Multiline = true;
            VencimentoPagar.Name = "VencimentoPagar";
            VencimentoPagar.Size = new Size(100, 347);
            VencimentoPagar.TabIndex = 43;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(1460, 110);
            label16.Name = "label16";
            label16.Size = new Size(75, 15);
            label16.TabIndex = 46;
            label16.Text = "Razao Social:";
            // 
            // RazaoSocialPagarText
            // 
            RazaoSocialPagarText.Location = new Point(1424, 131);
            RazaoSocialPagarText.Multiline = true;
            RazaoSocialPagarText.Name = "RazaoSocialPagarText";
            RazaoSocialPagarText.Size = new Size(155, 347);
            RazaoSocialPagarText.TabIndex = 45;
            RazaoSocialPagarText.TextChanged += RazaoSocialPagarText_TextChanged;
            // 
            // DiferencaPortal
            // 
            DiferencaPortal.AutoSize = true;
            DiferencaPortal.Location = new Point(826, 510);
            DiferencaPortal.Name = "DiferencaPortal";
            DiferencaPortal.Size = new Size(63, 15);
            DiferencaPortal.TabIndex = 47;
            DiferencaPortal.Text = "Diferença: ";
            // 
            // DiferencaPagar
            // 
            DiferencaPagar.AutoSize = true;
            DiferencaPagar.Location = new Point(1252, 510);
            DiferencaPagar.Name = "DiferencaPagar";
            DiferencaPagar.Size = new Size(63, 15);
            DiferencaPagar.TabIndex = 48;
            DiferencaPagar.Text = "Diferença: ";
            // 
            // DiferencaKardex
            // 
            DiferencaKardex.AutoSize = true;
            DiferencaKardex.Location = new Point(1730, 510);
            DiferencaKardex.Name = "DiferencaKardex";
            DiferencaKardex.Size = new Size(63, 15);
            DiferencaKardex.TabIndex = 49;
            DiferencaKardex.Text = "Diferença: ";
            // 
            // QuemFez
            // 
            QuemFez.AutoSize = true;
            QuemFez.Location = new Point(2083, 481);
            QuemFez.Name = "QuemFez";
            QuemFez.Size = new Size(64, 15);
            QuemFez.TabIndex = 50;
            QuemFez.Text = "Quem fez: ";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icon1;
            pictureBox1.Location = new Point(2277, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(60, 60);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 51;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.icon2;
            pictureBox2.Location = new Point(2343, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(60, 60);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 52;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(2213, 113);
            label9.Name = "label9";
            label9.Size = new Size(52, 15);
            label9.TabIndex = 54;
            label9.Text = "Revenda";
            // 
            // RevendasText
            // 
            RevendasText.Location = new Point(2189, 131);
            RevendasText.Multiline = true;
            RevendasText.Name = "RevendasText";
            RevendasText.Size = new Size(104, 347);
            RevendasText.TabIndex = 53;
            // 
            // button4
            // 
            button4.Location = new Point(2083, 80);
            button4.Name = "button4";
            button4.Size = new Size(320, 23);
            button4.TabIndex = 55;
            button4.Text = "Buscacha";
            button4.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(376, 488);
            label17.Name = "label17";
            label17.Size = new Size(61, 15);
            label17.TabIndex = 56;
            label17.Text = "Produtos: ";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(1688, 492);
            label18.Name = "label18";
            label18.Size = new Size(61, 15);
            label18.TabIndex = 57;
            label18.Text = "Produtos: ";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            textBox1.ForeColor = Color.Green;
            textBox1.Location = new Point(22, 12);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(345, 32);
            textBox1.TabIndex = 58;
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(373, 22);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(170, 23);
            textBox2.TabIndex = 59;
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(549, 22);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(170, 23);
            textBox3.TabIndex = 60;
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(376, 4);
            label19.Name = "label19";
            label19.Size = new Size(50, 15);
            label19.TabIndex = 61;
            label19.Text = "Emissão";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(549, 4);
            label20.Name = "label20";
            label20.Size = new Size(70, 15);
            label20.TabIndex = 62;
            label20.Text = "Vencimento";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(2335, 113);
            label21.Name = "label21";
            label21.Size = new Size(33, 15);
            label21.TabIndex = 64;
            label21.Text = "Conf";
            // 
            // ConfTextBox
            // 
            ConfTextBox.Location = new Point(2299, 131);
            ConfTextBox.Multiline = true;
            ConfTextBox.Name = "ConfTextBox";
            ConfTextBox.Size = new Size(104, 347);
            ConfTextBox.TabIndex = 63;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(2299, 481);
            label22.Name = "label22";
            label22.Size = new Size(68, 15);
            label22.TabIndex = 65;
            label22.Text = "Diferenças: ";
            // 
            // Frete
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(2411, 539);
            Controls.Add(label22);
            Controls.Add(label21);
            Controls.Add(ConfTextBox);
            Controls.Add(label20);
            Controls.Add(label19);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(button4);
            Controls.Add(label9);
            Controls.Add(RevendasText);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(QuemFez);
            Controls.Add(DiferencaKardex);
            Controls.Add(DiferencaPagar);
            Controls.Add(DiferencaPortal);
            Controls.Add(label16);
            Controls.Add(RazaoSocialPagarText);
            Controls.Add(label15);
            Controls.Add(VencimentoPagar);
            Controls.Add(label14);
            Controls.Add(VencimentoPortal);
            Controls.Add(button5);
            Controls.Add(ValorTotalPortal);
            Controls.Add(label12);
            Controls.Add(ValorDocPortal);
            Controls.Add(label13);
            Controls.Add(CtePortal);
            Controls.Add(SomaValorDoc);
            Controls.Add(button3);
            Controls.Add(label11);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label10);
            Controls.Add(PagadorPortal);
            Controls.Add(label3);
            Controls.Add(ValoresDoc);
            Controls.Add(CTE);
            Controls.Add(CTEText);
            Controls.Add(ValoresText);
            Controls.Add(label8);
            Controls.Add(CodigoProdutoKardex);
            Controls.Add(label6);
            Controls.Add(ValorSomado);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(ValorText);
            Controls.Add(RazaoSocialText);
            Controls.Add(FreteText);
            Controls.Add(Buscar);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(Buscacha);
            Controls.Add(Tabela);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximumSize = new Size(3000, 578);
            Name = "Frete";
            RightToLeft = RightToLeft.No;
            Text = "Frete";
            Load += Frete_Load;
            ((System.ComponentModel.ISupportInitialize)Tabela).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView Tabela;
        private TextBox Buscacha;
        private Label label1;
        private Label label2;
        private Button Buscar;
        private TextBox FreteText;
        private TextBox RazaoSocialText;
        private TextBox ValorText;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox ValorSomado;
        private Label label7;
        private Label DiferencaKardex;
        private TextBox CodigoProdutoKardex;
        private Label label8;
        private TextBox ValoresText;
        private Label CTE;
        private TextBox CTEText;
        private Label label3;
        private TextBox ValoresDoc;
        private Label label10;
        private TextBox PagadorPortal;
        private Button button1;
        private Button button2;
        private Label label11;
        private Button button3;
        private TextBox SomaValorDoc;
        private TextBox ValorTotalPortal;
        private Label label12;
        private TextBox ValorDocPortal;
        private Label label13;
        private TextBox CtePortal;
        private Button button5;
        private TextBox VencimentoPortal;
        private Label label14;
        private Label label15;
        private TextBox VencimentoPagar;
        private Label label16;
        private TextBox RazaoSocialPagarText;
        private Label DiferencaPortal;
        private Label DiferencaPagar;
        private Label QuemFez;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label9;
        private TextBox RevendasText;
        private Button button4;
        private Label label17;
        private Label label18;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Label label19;
        private Label label20;
        private Label label21;
        private TextBox ConfTextBox;
        private Label label22;
    }
}